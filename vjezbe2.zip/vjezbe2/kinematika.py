# kinematika.py

import numpy as np
import matplotlib.pyplot as plt

def jednoliko_gibanje(brzina, vrijeme):

   # Jednoliko gibanje: s = v * t
    t = np.linspace(0, vrijeme, 100)
    s = brzina * t

    plt.plot(t, s)
    plt.title("Jednoliko gibanje")
    plt.xlabel("Vrijeme (s)")
    plt.ylabel("Prijeđeni put (m)")
    plt.grid()
    plt.show()

def kosi_hitac(brzina, kut, vrijeme, g=9.81):
    """
    Kosi hitac
    """
    kut_rad = np.radians(kut)
    v_x = brzina * np.cos(kut_rad)
    v_y = brzina * np.sin(kut_rad)

    t = np.linspace(0, vrijeme, 100)
    x = v_x * t
    y = v_y * t - 0.5 * g * t**2

    plt.plot(x, y)
    plt.title("Kosi hitac")
    plt.xlabel("Put u x-smjeru (m)")
    plt.ylabel("Visina (m)")
    plt.grid()
    plt.show()

                  