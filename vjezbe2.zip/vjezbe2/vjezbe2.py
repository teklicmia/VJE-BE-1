# 1. zadatak
import numpy as np
import matplotlib.pyplot as plt

F = float(input("Unesite iznos sile u N (newtonima): "))
m = float(input("Unesite masu čestice u kg (kilogramima): "))

t_max = 10  
dt = 1  
t_values = np.arange(0, t_max, dt)  
x = 0  
v = 0  
a = F / m  

x_values = []
v_values = []
a_values = []

for t in t_values:
    x_values.append(x) 
    v_values.append(v)  
    a_values.append(a)  
    
    x = x + v * dt  # x = x + v * dt
    v = v + a * dt  # v = v + a * dt

print(x_values)
print(a_values)

plt.figure(figsize=(8, 6))

plt.subplot(3, 1, 1)
plt.plot(t_values, x_values, label="Položaj x(t)", color="blue")
plt.xlabel("Vrijeme (s)")
plt.ylabel("Položaj (m)")
plt.grid(True)

plt.subplot(3, 1, 2)
plt.plot(t_values, v_values, label="Brzina v(t)", color="green")
plt.xlabel("Vrijeme (s)")
plt.ylabel("Brzina (m/s)")
plt.grid(True)

plt.subplot(3, 1, 3)
plt.plot(t_values, a_values, label="Ubrzanje a(t)", color="red")
plt.xlabel("Vrijeme (s)")
plt.ylabel("Ubrzanje (m/s²)")
plt.grid(True)

plt.tight_layout()
plt.show()

#2. zadatak
import numpy as np
import matplotlib.pyplot as plt

v0 = float(input("Unesite iznos početne brzine u m/s: "))
theta = float(input("Unesite kut otklona u stupnjevima: "))
x = 0
y = 0
g = 9.81 
t_max = 10
dt = 1

v_x = v0 * np.cos(np.radians(theta))
v_y = v0 * np.sin(np.radians(theta))

t_values = np.arange(0, t_max, dt)
x_values = []
y_values = []
x_values.append(x)
y_values.append(y)

for t in t_values[1:]:
    v_y -= g * dt  # ubrzanje zbog gravitacije u y smjeru
    x += v_x * dt
    y += v_y * dt
    x_values.append(x)
    y_values.append(y)

# x-y graf
plt.figure(figsize=(8, 8))
plt.subplot(1, 3, 1)
plt.plot(x_values, y_values)
plt.title("x - y graf")
plt.xlabel("x [m]")
plt.ylabel("y [m]")
plt.grid(True)

# x-t graf
plt.subplot(1, 3, 2)
plt.plot(t_values, x_values)
plt.title("x - t graf")
plt.xlabel("Vrijeme [s]")
plt.ylabel("x [m]")
plt.grid(True)

# y-t graf
plt.subplot(1, 3, 3)
plt.plot(t_values, y_values)
plt.title("y - t graf")
plt.xlabel("Vrijeme [s]")
plt.ylabel("y [m]")
plt.grid(True)

plt.tight_layout()
plt.show()

# 3. zadatak
import kinematika

# Poziv funkcije za jednoliko gibanje
kinematika.jednoliko_gibanje(brzina=5, vrijeme=10)

# Poziv funkcije za kosi hitac
kinematika.kosi_hitac(brzina=20, kut=45, vrijeme=3)
















