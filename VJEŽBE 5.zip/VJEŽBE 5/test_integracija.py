import matplotlib.pyplot as plt
import math
from calculus import rectangle_integration, trapezoidal_integration

# Funkcija koju integriramo
def f(x):
    return x**2 + 2*x + 1  # (x + 1)^2

# Analitičko rješenje: ∫(x^2 + 2x + 1) dx = (1/3)x^3 + x^2 + x
def exact_integral(a, b):
    def F(x): return (1/3)*x**3 + x**2 + x
    return F(b) - F(a)

# Granice integracije
a = 0
b = 5
true_value = exact_integral(a, b)

# Lista broja podjela
n_values = [5, 10, 50, 100, 200]

rect_low = []
rect_high = []
trapz_vals = []
steps = []

for n in n_values:
    donja, gornja = rectangle_integration(f, a, b, n)
    trapz = trapezoidal_integration(f, a, b, n)

    rect_low.append(donja)
    rect_high.append(gornja)
    trapz_vals.append(trapz)
    steps.append(n)

    print(f"n={n} | Pravokutna suma: [{donja:.5f}, {gornja:.5f}] | Trapezna: {trapz:.5f} | Točna: {true_value:.5f}")

# Crtanje
plt.figure()
plt.hlines(true_value, steps[0], steps[-1], colors='black', linestyles='solid', label='Analitičko rješenje')
plt.plot(steps, rect_low, 'o--', label='Donja suma')
plt.plot(steps, rect_high, 'o--', label='Gornja suma')
plt.plot(steps, trapz_vals, 'o-', label='Trapezna metoda')
plt.xlabel("Broj podjela (n)")
plt.ylabel("Vrijednost integrala")
plt.title("Numerička integracija vs. analitičko rješenje")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()
