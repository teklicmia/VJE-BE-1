def derivative_at_point(f, x, epsilon=1e-5, method="three-step"):
    if method == "three-step":
        return (f(x + epsilon) - f(x - epsilon)) / (2 * epsilon)
    elif method == "two-step":
        return (f(x + epsilon) - f(x)) / epsilon
    else:
        raise ValueError("Nepoznata metoda: koristi 'three-step' ili 'two-step'")


def derivative_on_interval(f, xmin, xmax, step=0.1, epsilon=1e-5, method="three-step"):
    x_vals = []
    deriv_vals = []

    x = xmin
    while x <= xmax:
        deriv = derivative_at_point(f, x, epsilon=epsilon, method=method)
        x_vals.append(x)
        deriv_vals.append(deriv)
        x += step

    return x_vals, deriv_vals

#2 ZADATAK

def rectangle_integration(f, a, b, n):
    h = (b - a) / n
    donja_suma = 0
    gornja_suma = 0

    for i in range(n):
        x_left = a + i * h
        x_right = a + (i + 1) * h
        donja_suma += min(f(x_left), f(x_right)) * h
        gornja_suma += max(f(x_left), f(x_right)) * h

    return donja_suma, gornja_suma


def trapezoidal_integration(f, a, b, n):
    h = (b - a) / n
    integral = 0.5 * (f(a) + f(b))

    for i in range(1, n):
        x = a + i * h
        integral += f(x)

    return integral * h

