def derivative_at_point(f, x, epsilon=1e-5, method="three-step"):
    if method == "three-step":
        return (f(x + epsilon) - f(x - epsilon)) / (2 * epsilon)
    elif method == "two-step":
        return (f(x + epsilon) - f(x)) / epsilon
    else:
        raise ValueError("Nepoznata metoda: koristi 'three-step' ili 'two-step'")


def derivative_on_interval(f, xmin, xmax, step=0.1, epsilon=1e-5, method="three-step"):
    x_vals = []
    deriv_vals = []

    x = xmin
    while x <= xmax:
        deriv = derivative_at_point(f, x, epsilon=epsilon, method=method)
        x_vals.append(x)
        deriv_vals.append(deriv)
        x += step

    return x_vals, deriv_vals
