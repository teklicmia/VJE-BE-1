import matplotlib.pyplot as plt
import math
from calculus import derivative_at_point, derivative_on_interval

def cubic(x):
    return x**3 - 2*x**2 + x

def trig(x):
    return math.sin(x)

def cubic_derivative(x):
    return 3*x**2 - 4*x + 1

def trig_derivative(x):
    return math.cos(x)

f = cubic
f_prime = cubic_derivative
xmin, xmax = -2, 3

epsilons = [1e-1, 1e-3, 1e-5]
methods = ['three-step', 'two-step']

x_real = [x / 100 for x in range(int(xmin*100), int(xmax*100)+1)]
y_real = [f_prime(x) for x in x_real]

plt.plot(x_real, y_real, label="Analitička derivacija", color="black")

colors = ['red', 'blue', 'green', 'orange', 'purple']
i = 0
for method in methods:
    for eps in epsilons:
        x_vals, y_vals = derivative_on_interval(f, xmin, xmax, step=0.1, epsilon=eps, method=method)
        plt.plot(x_vals, y_vals, linestyle='--', marker='o', markersize=3,
                 label=f"{method}, ε={eps}", color=colors[i % len(colors)])
        i += 1

plt.xlabel("x")
plt.ylabel("f'(x)")
plt.title("Usporedba analitičke i numeričke derivacije")
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.show()
